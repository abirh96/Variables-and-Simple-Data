#Requirements 1-3
first_name = "abir"
last_name = "HAQUE"

first_name = first_name.lower() # First name variable gets converted to all lowercase
last_name = last_name.upper() # Last name variable gets converted to all uppercase

print("Hello, " + first_name + " " + last_name)
#Requirements 1-3


#Requirements 4-5
print("\n\n") # prints out 2 newlines

print("\"Start by doing what's necessary; then do what's possible; and suddenly you are doing the impossible - Francis of Assisi\"") # Quotes are kept by using \"INSERT QUOTE\"
#Requirements 4-5


#Requirements 6-8
decimalOne = 1.5
decimalTwo = 3.7

addition_result = decimalOne + decimalTwo 
subtraction_result = decimalOne - decimalTwo
multiplication_result = decimalOne * decimalTwo
division_result = decimalOne / decimalTwo

print("\n" + str(decimalOne) + " plus " + str(decimalTwo) + " equals " + str(addition_result)) # Need to convert to string to concatenate. 
print("\n" + str(decimalOne) + " minus " + str(decimalTwo) + " equals " + str(subtraction_result))
print("\n" + str(decimalOne) + " times " + str(decimalTwo) + " equals " + str(multiplication_result))
print("\n" + str(decimalOne) + " divided by " + str(decimalTwo) + " equals " + str(division_result))
#Requirements 6-8


#Requirements 9-10
month_variable = "November"
day_variable = 11

print("\n\t\t" + "Today is day " + str(day_variable) + " " + "of the month " + month_variable + ".") # Same as earlier but only have to convert the day_variable
#Requirements 9-10